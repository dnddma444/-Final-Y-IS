# gemini_service.py - Generate chapter titles using Gemini model
import os
import pandas as pd
from tqdm import tqdm
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

# 환경 변수에서 Gemini API 키 로드
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
model = genai.GenerativeModel("models/gemini-1.5-flash")

def generate_chapter_titles(input_path, output_dir):
    try:
        # CSV 파일 로드
        df = pd.read_csv(input_path)
        df = df[['block_index', 'text', 'timestamp']].dropna()
        df.columns = ['index', 'text', 'timestamp']

        chapter_data = []

        for idx, group in tqdm(df.groupby("index")):
            text_block = " ".join(group["text"].tolist())[:1500]
            timestamp = group["timestamp"].iloc[0]

            prompt = f"""
다음 자막 내용을 대표할 수 있는 간결한 한국어 챕터 제목을 **한 문장으로** 작성해 주세요.
- 설명하지 마세요
- 제목 후보를 나열하지 마세요.
- '**' 또는 인용 부호 없이 제목 **내용만** 출력하세요.
- 자막 내용이 부족해도 임의로 가장 적절한 제목을 만들어 주세요.

[자막 내용]
{text_block}
"""

            try:
                response = model.generate_content(prompt)
                if response and response.text:
                    title = response.text.strip().split("\n")[0].replace('"', '').replace("'", "")
                    if not title:
                        title = "내용 요약"
                else:
                    title = "내용 요약"
            except Exception as e:
                print(f"[WARN] Gemini 생성 실패 - index={idx}, 이유: {str(e)}")
                title = "내용 요약"

            chapter_data.append({
                "index": idx,
                "timestamp": timestamp,
                "chapter_title": title
            })

        # 저장 경로
        os.makedirs(output_dir, exist_ok=True)
        output_path = os.path.join(output_dir, "chapters.csv")

        # 저장
        chapter_df = pd.DataFrame(chapter_data)
        chapter_df.to_csv(output_path, index=False, encoding="utf-8")
        print("[INFO] 챕터 제목 저장 완료:", output_path)

        return output_path

    except Exception as e:
        print(f"[ERROR] Chapter title generation failed: {str(e)}")
        return None