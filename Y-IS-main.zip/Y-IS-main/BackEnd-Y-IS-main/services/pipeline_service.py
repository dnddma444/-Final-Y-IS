import shutil
import subprocess
import os
import pandas as pd
import uuid

from services.whisper_service import transcribe_audio
from services.db_service import save_metadata, save_sentences
from services.gemini_service import generate_chapter_titles
from services.grouping_service import apply_chapter_groups
from models.video import Video  # ✅ DB에서 category 다시 불러오기 위해 필요

def convert_mp4_to_mp3(mp4_path):
    mp3_path = mp4_path.replace(".mp4", ".mp3")
    try:
        subprocess.run(['ffmpeg', '-i', mp4_path, '-q:a', '0', '-map', 'a', mp3_path], check=True)
        print(f"[INFO] MP4 to MP3 conversion successful: {mp3_path}")
        return mp3_path
    except Exception as e:
        print(f"[ERROR] MP4 to MP3 conversion failed: {str(e)}")
        return None

def process_video(video_path, video_id, user_id, category):
    try:
        # Step 1: Convert MP4 to MP3
        audio_path = convert_mp4_to_mp3(video_path)
        if not audio_path:
            print("[ERROR] Audio conversion failed.")
            return None

        # Step 2: Transcribe audio with CSV save
        transcription_csv_path = os.path.join(os.path.dirname(audio_path), "transcription.csv")
        transcription = transcribe_audio(audio_path, save_csv=True, output_path=transcription_csv_path)
        if not transcription:
            print("[ERROR] Transcription failed.")
            return None

        # Step 3: Save initial metadata before sentences to respect FK constraint
        metadata = {
            "video_id": str(video_id),
            "user_id": user_id,
            "category": category,
            "status": "processing",
            "file_url": video_path
        }
        save_metadata(video_id, metadata)

        # Step 4: Save sentences to DB
        save_sentences(video_id, transcription)

        # Step 5: Group chapters
        apply_chapter_groups(transcription_csv_path)

        # Step 6: Generate chapter titles
        output_dir = os.path.dirname(transcription_csv_path)
        grouped_csv_path = transcription_csv_path.replace("transcription.csv", "grouped.csv")
        chapter_path = generate_chapter_titles(grouped_csv_path, output_dir)
        if not chapter_path:
            print("[ERROR] Chapter title generation failed.")
            return None

        # Step 7: Generate summary
        try:
            chapter_df = pd.read_csv(chapter_path)
            summary = " / ".join(chapter_df["chapter_title"].tolist()[:5])
        except Exception as e:
            print(f"[ERROR] Summary generation failed: {str(e)}")
            summary = "N/A"

        # ✅ Step 8: Update metadata with final values, preserving category from DB
        existing_video = Video.query.filter_by(video_id=str(video_id)).first()
        category_from_db = existing_video.category if existing_video else category

        metadata.update({
            "status": "completed",
            "summary": summary,
            "category": category_from_db
        })
        save_metadata(video_id, metadata)

        print("[INFO] Pipeline completed successfully.")
        return metadata
    except Exception as e:
        print(f"[ERROR] Pipeline processing failed: {str(e)}")
        return None
