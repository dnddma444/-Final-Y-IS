from sqlalchemy.exc import SQLAlchemyError
from models import db, Video
from models.sentence import Sentence

def save_sentences(video_id, sentences):
    try:
        sentence_objects = []
        for idx, item in enumerate(sentences):
            sentence = Sentence(
                video_id=video_id,
                number=idx + 1,
                start_time=item['timestamp'],
                contents=item['text'],
                group_number=0  # 초기 그룹 번호
            )
            sentence_objects.append(sentence)

        db.session.bulk_save_objects(sentence_objects)
        db.session.commit()
        print(f"[INFO] Saved {len(sentences)} sentences for video {video_id}")
    except Exception as e:
        db.session.rollback()
        print(f"[ERROR] Failed to save sentences: {str(e)}")

def save_metadata(video_id, metadata):
    try:
        video = Video.query.filter_by(id=video_id).first()

        if video:
            # update only if value is not None
            if metadata.get("user_id") is not None:
                video.user_id = metadata["user_id"]
            if metadata.get("category") is not None:
                video.category = metadata["category"]
            if metadata.get("status") is not None:
                video.status = metadata["status"]
            if metadata.get("file_url") is not None:
                video.file_url = metadata["file_url"]
            if metadata.get("summary") is not None:
                video.summary = metadata["summary"]
        else:
            video = Video(
                id=video_id,
                video_id=str(video_id),
                user_id=metadata.get("user_id", "unknown"),
                category=metadata.get("category") or ["기본"],  # ✅ 이 부분만 기본값
                status=metadata.get("status", "unknown"),
                file_url=metadata.get("file_url", "N/A"),
                summary=metadata.get("summary", "N/A")
            )
            db.session.add(video)

        db.session.commit()
        print(f"[INFO] Metadata saved/updated for video ID: {video_id}")
    except SQLAlchemyError as e:
        db.session.rollback()
        print(f"[ERROR] Failed to save metadata: {str(e)}")
    except Exception as e:
        db.session.rollback()
        print(f"[ERROR] Unexpected error while saving metadata: {str(e)}")

def get_metadata(video_id):
    """PostgreSQL에서 메타데이터 가져오기"""
    try:
        video = Video.query.filter_by(video_id=video_id).first()
        if video:
            return {
                "video_id": video.video_id,
                "user_id": video.user_id,
                "category": video.category,
                "status": video.status,
                "file_url": video.file_url,
                "summary": video.summary
            }
        return None
    except SQLAlchemyError as e:
        print(f"[ERROR] 메타데이터 가져오기 실패: {e}")
        return None
