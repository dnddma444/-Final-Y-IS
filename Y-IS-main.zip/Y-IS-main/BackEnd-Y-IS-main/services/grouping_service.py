import pandas as pd
import numpy as np
from tqdm import tqdm
from sentence_transformers import SentenceTransformer, util


def load_and_preprocess_transcription(csv_path):
    df = pd.read_csv(csv_path)
    df = df[df["text"].str.strip() != ""].reset_index(drop=True)
    return df


def compute_embeddings(df, model_name="snunlp/KR-SBERT-V40K-klueNLI-augSTS"):
    model = SentenceTransformer(model_name)
    embeddings = [model.encode(text, convert_to_tensor=True) for text in tqdm(df["text"])]
    return embeddings, model


def split_blocks(df, embeddings, min_block_len=12):
    similarities = [util.cos_sim(embeddings[i-1], embeddings[i]).item() for i in range(1, len(embeddings))]
    sim_mean = np.mean(similarities)
    sim_std = np.std(similarities)
    threshold = sim_mean - 0.3 * sim_std

    block_indices = []
    current_block = [df["text"][0]]
    block_id = 0

    for i in range(1, len(df)):
        sim = util.cos_sim(embeddings[i-1], embeddings[i]).item()
        if sim < threshold and len(current_block) >= min_block_len:
            block_indices += [block_id] * len(current_block)
            block_id += 1
            current_block = [df["text"][i]]
        else:
            current_block.append(df["text"][i])

    if current_block:
        block_indices += [block_id] * len(current_block)

    df = df.iloc[:len(block_indices)].copy()
    df["block_index"] = block_indices
    return df


def merge_blocks(df, model, thresholds=[0.65, 0.55]):
    for t in thresholds:
        print(f"Merging blocks with threshold {t}...")
        grouped = df.groupby("block_index")["text"].apply(lambda x: " ".join(x)).tolist()
        embeddings = [model.encode(text, convert_to_tensor=True) for text in tqdm(grouped)]

        new_indices = []
        group_id = 0
        new_indices.append(group_id)

        for i in range(1, len(embeddings)):
            sim = util.cos_sim(embeddings[i-1], embeddings[i]).item()
            if sim >= t:
                new_indices.append(group_id)
            else:
                group_id += 1
                new_indices.append(group_id)

        block_map = dict(zip(df["block_index"].unique(), new_indices))
        df["block_index"] = df["block_index"].map(block_map)
    return df


def apply_chapter_groups(csv_path):
    df = load_and_preprocess_transcription(csv_path)
    embeddings, model = compute_embeddings(df)
    df = split_blocks(df, embeddings)
    df = merge_blocks(df, model)

    output_path = csv_path.replace("transcription.csv", "grouped.csv")
    df.to_csv(output_path, index=False)
    print(f"[INFO] Saved grouped CSV: {output_path}")
    return output_path
