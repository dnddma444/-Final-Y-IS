from datetime import timedelta
import whisper
import os
import pandas as pd
import re

# Whisper 모델 로딩
model = whisper.load_model("base")

# 텍스트 정제 함수
def clean_text(text):
    text = re.sub(r"[,.!?]{2,}", lambda m: m.group(0)[0], text)
    text = re.sub(r"[^\uAC00-\uD7A3a-zA-Z0-9\s,.!?]", "", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()

def transcribe_audio(file_path, save_csv=False, output_path=None):
    try:
        # Transcribe audio file
        result = model.transcribe(file_path)

        # Extract segments
        segments = []
        for i,segment in enumerate(result['segments']):
            start_time = str(timedelta(seconds=int(segment['start'])))
            text = segment['text'].strip()
            segments.append({
                "block_index": i,  # 🔹 초기에는 비워두고 나중에 grouping 단계에서 채움
                "timestamp": start_time,
                "text": text
            })

        # Save to CSV if requested
        if save_csv and output_path:
            df = pd.DataFrame(segments)[["block_index", "timestamp", "text"]]
            df.to_csv(output_path, index=False, encoding='utf-8')
            print(f"[INFO] CSV saved at {output_path}")

        # Return the transcription result
        return segments
    except Exception as e:
        print(f"[ERROR] Transcription failed: {str(e)}")
        return None

# 테스트 실행
if __name__ == "__main__":
    sample_audio = "sample.mp3"
    output_csv = "sample_transcription.csv"

    if os.path.exists(sample_audio):
        transcription = transcribe_audio(sample_audio, save_csv=True, output_path=output_csv)
        print(transcription)
    else:
        print("Sample audio file not found.")