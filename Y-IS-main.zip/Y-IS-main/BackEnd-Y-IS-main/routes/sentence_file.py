from flask import Blueprint, jsonify
import os
import pandas as pd

sentence_file_bp = Blueprint("sentence_file", __name__)

@sentence_file_bp.route("/sentences/file/<video_id>", methods=["GET"])
def get_sentences_from_csv(video_id):
    try:
        # CSV 파일 경로 설정
        base_dir = os.path.join("static", "uploads", video_id)
        grouped_path = os.path.join(base_dir, "grouped.csv")

        if not os.path.exists(grouped_path):
            return jsonify({"error": "grouped.csv not found"}), 404

        df = pd.read_csv(grouped_path)

        # block_index로 그룹화하여 묶기
        grouped_result = []
        for block_index, group_df in df.groupby("block_index"):
            sentences = group_df["text"].tolist()
            timestamp = group_df.iloc[0]["start"]
            chapter_title = group_df.iloc[0].get("chapter_title", "제목 없음")

            grouped_result.append({
                "id": int(block_index),
                "timestamp": timestamp,
                "chapter_title": chapter_title,
                "sentences": sentences
            })

        return jsonify(grouped_result), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500
