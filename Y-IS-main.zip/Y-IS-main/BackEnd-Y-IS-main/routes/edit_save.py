from flask import Blueprint, request, jsonify
from models import db
from models.sentence import Sentence

edit_bp = Blueprint("edit", __name__)

@edit_bp.route("/edit/save/<video_id>", methods=["POST"])

def save_edits(video_id):
    try:
        data = request.get_json()
        blocks = data.get("blocks", [])

        if not blocks:
            return jsonify({"error": "No blocks provided"}), 400

        # Remove old sentences for this video
        Sentence.query.filter_by(video_id=video_id).delete()

        for group_number, block in enumerate(blocks):
            timestamp = block.get("timestamp")
            chapter_title = block.get("chapter_title", f"Chapter {group_number+1}")
            sentences = block.get("sentences", [])

            for number, sentence_text in enumerate(sentences):
                sentence = Sentence(
                    video_id=video_id,
                    group_number=group_number,
                    number=number,
                    contents=sentence_text,
                    start_time=timestamp,
                    chapter_title=chapter_title
                )
                db.session.add(sentence)

        db.session.commit()
        return jsonify({"message": "Edits saved successfully"}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500
