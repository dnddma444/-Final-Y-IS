from flask import Blueprint, jsonify, request
from models.sentence import Sentence
from models import db
from collections import defaultdict
from sqlalchemy import asc
import os
import pandas as pd

summary_bp = Blueprint("summary", __name__)
sentence_bp = Blueprint("sentence", __name__)

@sentence_bp.route("/sentences/update/<video_id>", methods=["PATCH"])
def update_sentences(video_id):
    try:
        data = request.get_json()
        blocks = data.get("blocks", [])

        if not blocks:
            return jsonify({"error": "No blocks provided"}), 400

        # ✅ 기존 문장 삭제
        Sentence.query.filter_by(video_id=video_id).delete()

        for group_index, block in enumerate(blocks):
            timestamp = block.get("timestamp")
            chapter_title = block.get("chapter_title", f"Chapter {group_index+1}")
            sentences = block.get("sentences", [])

            for number, sentence in enumerate(sentences):
                text = sentence.get("text", "") if isinstance(sentence, dict) else sentence
                start_time = sentence.get("timestamp", timestamp)

                new_sentence = Sentence(
                    video_id=video_id,
                    number=number,
                    start_time=str(start_time),
                    contents=text,
                    group_number=group_index,
                    chapter_title=chapter_title
                )
                db.session.add(new_sentence)

        db.session.commit()
        return jsonify({"message": "Sentences updated successfully"}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500
    
@summary_bp.route("/sentences/summary/<video_id>", methods=["GET"])
def get_chapter_summary(video_id):
    try:
        output_dir = os.path.join("static", "uploads", video_id)
        chapter_csv = os.path.join(output_dir, "chapters.csv")
        grouped_csv = os.path.join(output_dir, "grouped.csv")

        if not os.path.exists(chapter_csv):
            return jsonify({"error": "chapters.csv not found"}), 404
        if not os.path.exists(grouped_csv):
            return jsonify({"error": "grouped.csv not found"}), 404

        # ✅ 데이터 로드
        chapter_df = pd.read_csv(chapter_csv)
        grouped_df = pd.read_csv(grouped_csv)

        # ✅ block_index별 문장 + 타임스탬프 포함
        sentence_map = (
            grouped_df.groupby("block_index")
            .apply(lambda g: [
                {"text": row["text"], "timestamp": row["timestamp"]}
                for _, row in g.iterrows()
            ])
            .to_dict()
        )

        timestamp_map = grouped_df.groupby("block_index")["timestamp"].first().to_dict()

        response = []
        for idx, row in chapter_df.iterrows():
            chapter_title = row.get("chapter_title", f"Chapter {idx + 1}")
            sentences = sentence_map.get(idx, [])
            timestamp = timestamp_map.get(idx, "00:00:00")

            response.append({
                "id": str(idx),
                "chapter_title": chapter_title,
                "timestamp": timestamp,
                "sentences": sentences
            })

        return jsonify(response), 200

    except Exception as e:
        return jsonify({"error": f"Failed to load chapter summary: {str(e)}"}), 500
from flask import request, jsonify
import os
import pandas as pd
from services.gemini_service import generate_chapter_titles

@sentence_bp.route("/sentences/finalize/<video_id>", methods=["POST"])
def finalize_chapters(video_id):
    try:
        data = request.get_json()

        if not isinstance(data, list):
            return jsonify({"error": "Invalid data format. Expected list."}), 400

        # 🎯 저장 디렉토리 구성
        output_dir = os.path.join("outputs", video_id)
        os.makedirs(output_dir, exist_ok=True)

        # ✅ fixed_chapters.csv 저장
        df = pd.DataFrame(data)
        df["block_index"] = df.index
        df["text"] = df["sentences"].apply(
            lambda s: "||".join(
                [item["text"] if isinstance(item, dict) else str(item) for item in s]
            )
        )
        df.to_csv(os.path.join(output_dir, "fixed_chapters.csv"), index=False)

        # ✅ 유저가 수정한 제목 + 타임스탬프 반영해서 chapters.csv 저장
        chapters_path = os.path.join("static", "uploads", video_id, "chapters.csv")
        os.makedirs(os.path.dirname(chapters_path), exist_ok=True)

        chapter_df = df[["block_index", "timestamp", "chapter_title"]]
        chapter_df.to_csv(chapters_path, index=False)

        return jsonify({"message": "Finalized with user edits"}), 200

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": f"Finalization failed: {str(e)}"}), 500