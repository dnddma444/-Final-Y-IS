from flask import Blueprint, jsonify
from models.video import Video
from sqlalchemy.exc import DataError
import uuid
import os
import pandas as pd

status_bp = Blueprint('status', __name__)

@status_bp.route('/status/<video_id>', methods=['GET'])
def get_video_status(video_id):
    try:
        # 1. video_id → UUID 형식 변환
        try:
            uuid_obj = uuid.UUID(video_id)
        except ValueError:
            return jsonify({'error': 'Invalid video ID format'}), 400

        # 2. video 테이블에서 해당 메타데이터 조회
        video = Video.query.filter_by(video_id=str(uuid_obj)).first()
        if not video:
            return jsonify({'error': 'Video not found'}), 404

        # 3. chapters.csv 경로 추정
        base_dir = os.path.dirname(video.file_url)
        csv_path = os.path.join(base_dir, "chapters.csv")

        # 4. CSV 파일에서 blocks 리스트 추출
        blocks = []
        if os.path.exists(csv_path):
            df = pd.read_csv(csv_path)
            for _, row in df.iterrows():
                blocks.append({
                    "timestamp": row["timestamp"],
                    "chapter_title": row["chapter_title"]
                })

        return jsonify({
            'video_id': video.video_id,
            'status': video.status,
            'metadata': {
                'user_id': video.user_id,
                'category': video.category,
                'summary': video.summary,
                'file_url': video.file_url,
                'blocks': blocks  # ✅ 여기서 chapters.csv 기반 blocks 주입
            }
        }), 200
    except DataError:
        return jsonify({'error': 'Invalid video ID format in database'}), 400
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500