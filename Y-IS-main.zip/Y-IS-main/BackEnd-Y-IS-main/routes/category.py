#routes/category.py
from flask import Blueprint, request, jsonify
from models import db
from models.video import Video
import re

category_bp = Blueprint("category", __name__)

def remove_emoji(text):
    emoji_pattern = re.compile("[\U00010000-\U0010ffff]", flags=re.UNICODE)
    return emoji_pattern.sub(r"", text)

@category_bp.route("/category", methods=["POST"])
def category():
    try:
        data = request.get_json()
        video_id = data.get("video_id")
        category_list = data.get("category")

        if not video_id or not category_list:
            return jsonify({"error": "video_id and category are required"}), 400

        if not isinstance(category_list, list):
            return jsonify({"error": "category must be a list"}), 400

        if not all(isinstance(item, str) for item in category_list):
            return jsonify({"error": "Each category must be a string"}), 400

        video = Video.query.filter_by(video_id=video_id).first()
        if not video:
            return jsonify({"error": "Video not found"}), 404

        # ✅ JSON 컬럼에 이모지를 제거한 리스트 저장
        cleaned_category = [remove_emoji(c).strip() for c in category_list if remove_emoji(c).strip()]
        video.category = cleaned_category
        db.session.commit()

        return jsonify({"message": "Category updated successfully"}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500
