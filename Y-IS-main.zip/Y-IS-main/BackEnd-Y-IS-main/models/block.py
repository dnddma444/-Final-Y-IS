# models/block.py
from models.db import db
import uuid
from sqlalchemy.dialects.postgresql import UUID

class Block(db.Model):
    __tablename__ = 'blocks'

    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    video_id = db.Column(UUID(as_uuid=True), db.ForeignKey('videos.id', ondelete='CASCADE'), nullable=False)
    start_time = db.Column(db.String(50), nullable=False)
    end_time = db.Column(db.String(50), nullable=False)
    summary = db.Column(db.Text, nullable=True)