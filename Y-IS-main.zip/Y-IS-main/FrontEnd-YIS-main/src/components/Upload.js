import React, { useRef, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const allowedExtensions = [
  "mp3",
  "mp4",
  "m4a",
  "wav",
  "flac",
  "webm",
  "ogg",
  "opus",
];

export default function Upload() {
  const navigate = useNavigate();
  const { file, fileName, setFile, setFileName } = useApp();
  const fileInputRef = useRef(null);

  useEffect(() => {
    if (!file && fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  }, [file]);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (!selectedFile) return;

    const extension = selectedFile.name.split(".").pop().toLowerCase();
    if (allowedExtensions.includes(extension)) {
      setFileName(selectedFile.name);
      setFile(selectedFile);
    } else {
      alert("⚠️ 영상 파일을 업로드 해주세요.\n허용된 파일 형식: mp3, mp4, ...");
      e.target.value = null;
    }
  };

  const uploadToServer = async (file, category, user_id = "test_id", need_summary = true) => {
    if (!file) return;
  
    const formData = new FormData();
    formData.append("file", file); // ✅ key는 'file'로
    formData.append("category", category);
    formData.append("user_id", user_id);
    formData.append("need_summary", String(need_summary)); // 문자열 "True" 또는 "False"
  
    try {
      const response = await axios.post(
        "http://localhost:5555/upload", // ⬅️ 또는 실제 IP 주소
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      console.log("✅ 업로드 성공:", response.data);
      return response.data;
    } catch (error) {
      console.error("❌ 업로드 실패:", error);
      throw error;
    }
  };

  return (
    <div className="container">
      <h1>Y-IS</h1>
      <div className="upload-box">
        <p>여기에 영상 파일을 드래그하거나 업로드하세요.</p>
        <input
          ref={fileInputRef}
          type="file"
          accept=".mp3,.mp4,.m4a,.wav,.flac,.webm,.ogg,.opus"
          onChange={handleFileChange}
        />
        {fileName && <p>선택된 파일: {fileName}</p>}

        <div className="button-group" style={{ marginTop: 20 }}>
          <button onClick={() => navigate("/")}>이전으로</button>
          <button
            onClick={async () => {
              if (file && fileName) {
                try {
                  const result = await uploadToServer(file);
                  navigate("/category", {
                    state: { file, fileName, video_id: result.video_id },
                  });
                } catch (err) {
                  alert("서버 업로드에 실패했습니다.");
                }
              } else {
                alert("파일을 업로드 해주세요!");
              }
            }}
          >
            업로드 완료
          </button>
        </div>
      </div>
    </div>
  );
}