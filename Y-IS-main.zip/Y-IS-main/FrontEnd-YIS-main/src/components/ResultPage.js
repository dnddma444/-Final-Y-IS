import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import downloadTextFile from "./downloadTextFile";
import { useBlocks } from "../context/BlocksContext";
import { useApp } from "../context/AppContext";
import axios from "axios";
import "../style/ResultEditStyles.css";

export default function ResultPage() {
  const { videoId } = useParams();
  const navigate = useNavigate();
  const { setBlocks, blocks } = useBlocks();
  const {
    fileName,
    setFileName,
    selectedCategories,
    setSelectedCategories,
  } = useApp();

  const [videoUrl, setVideoUrl] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const apiUrl = process.env.REACT_APP_API_URL;
        const res = await axios.get(`${apiUrl}/sentences/summary/${videoId}`);
        const fetchedBlocks = res.data.map((b, idx) => ({
          ...b,
          timestamp: parseTimeString(b.timestamp),
        }));

        setBlocks(fetchedBlocks);
        setVideoUrl(`${apiUrl}/static/uploads/${videoId}/${videoId}.mp4`);
      } catch (err) {
        alert("결과 데이터를 불러오는 데 실패했습니다.");
        navigate("/");
      }
    };

    fetchData();
  }, [videoId]);

  const handleEditClick = () => {
    navigate(`/edit/${videoId}`);
  };

  return (
    <div className="page-wrapper">
      <h1 className="header-title">Y-IS</h1>
      <div className="card">
        <div className="flex-row">
          <div className="video-container">
            {videoUrl ? (
              <video controls className="video-player">
                <source src={videoUrl} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            ) : (
              <div
                style={{
                  width: "100%",
                  height: "200px",
                  backgroundColor: "#e5e7eb",
                  borderRadius: "12px",
                }}
              />
            )}
          </div>

          <div className="text-container">
            <div>
              <div className="label">제목</div>
              <div className="value-box">{fileName}</div>
            </div>
            <div style={{ marginTop: "12px" }}>
              <div className="label">카테고리</div>
              <div className="value-box">
                {Array.from(selectedCategories).join(", ")}
              </div>
            </div>
          </div>
        </div>

        <div className="timestamp-box">
          {blocks.map((b, i) => (
            <div key={i}>
              {formatTime(b.timestamp)} - {b.chapter_title || b.summary}
            </div>
          ))}
        </div>

        <div className="button-row">
          <button onClick={handleEditClick} className="button">
            ✏️ 수정하기
          </button>
          <button
            onClick={() =>
              downloadTextFile(blocks, () => {
                navigate("/complete");
              })
            }
            className="button"
          >
            📄 텍스트로 저장
          </button>
        </div>
      </div>
    </div>
  );
}

// ✅ 시간 포맷
function formatTime(seconds) {
  if (typeof seconds !== "number" || isNaN(seconds)) return "00:00";
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  return hrs > 0
    ? `${hrs.toString().padStart(2, "0")}:${mins
        .toString()
        .padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
    : `${mins.toString().padStart(2, "0")}:${secs
        .toString()
        .padStart(2, "0")}`;
}

// ✅ 문자열 "00:02:13" -> 초로 변환
function parseTimeString(timeStr) {
  if (!timeStr || typeof timeStr !== "string") return 0;
  const parts = timeStr.split(":").map(Number);
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  return 0;
}