import React, { useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import styles from "../style/ToggleHandleStyles.module.css";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import DeleteIcon from "@mui/icons-material/Delete";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";

function formatTime(seconds) {
  if (typeof seconds !== "number" || isNaN(seconds)) return "00:00";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return h > 0
    ? `${h.toString().padStart(2, "0")}:${m
        .toString()
        .padStart(2, "0")}:${s.toString().padStart(2, "0")}`
    : `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

const parseTime = (str) => {
  const parts = str.split(":").map(Number);
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  return Number(str);
};

export default function EditPage() {
  const { videoId } = useParams();
  const navigate = useNavigate();
  const videoRef = useRef(null);
  const apiUrl = process.env.REACT_APP_API_URL;

  const [blocks, setBlocks] = useState([]);
  const [expanded, setExpanded] = useState([]);
  const [videoUrl, setVideoUrl] = useState(null);
  const [newTitle, setNewTitle] = useState("");
  const [newTime, setNewTime] = useState("");
  const [editingChapterId, setEditingChapterId] = useState(null);
  const [tempTitle, setTempTitle] = useState("");

  const [anchorEl, setAnchorEl] = useState(null);
  const [menuSentence, setMenuSentence] = useState(null);
  const open = Boolean(anchorEl);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(`${apiUrl}/sentences/summary/${videoId}`);
        const data = res.data.map((b, idx) => ({
          id: `block-${idx}`,
          chapter_title: b.chapter_title,
          timestamp: parseTime(b.timestamp),
          sentences: b.sentences.map((s, i) => ({
            id: `sent-${idx}-${i}`,
            text: typeof s === "string" ? s : s.text,
            timestamp: parseTime(s.timestamp ?? b.timestamp),
          })),
        }));
        setBlocks(data);
        setVideoUrl(`${apiUrl}/static/uploads/${videoId}/${videoId}.mp4`);
      } catch (err) {
        alert("데이터를 불러오는 데 실패했습니다.");
        navigate(-1);
      }
    };

    fetchData();
  }, [videoId]);

  const handleToggle = (id) => {
    setExpanded((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const handleSentenceChange = (blockId, sentId, text) => {
    setBlocks((prev) =>
      prev.map((b) =>
        b.id === blockId
          ? {
              ...b,
              sentences: b.sentences.map((s) =>
                s.id === sentId ? { ...s, text } : s
              ),
            }
          : b
      )
    );
  };

  const handleMenuOpen = (e, blockId, sentenceIndex) => {
    setAnchorEl(e.currentTarget);
    setMenuSentence({ blockId, sentenceIndex });
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    setMenuSentence(null);
  };

  const moveSentence = (direction) => {
    const { blockId, sentenceIndex } = menuSentence;
    const blockIdx = blocks.findIndex((b) => b.id === blockId);
    if (blockIdx < 0) return;

    const sentenceGroup = blocks[blockIdx].sentences;
    let targetBlockIdx = direction === "up" ? blockIdx - 1 : blockIdx + 1;
    if (targetBlockIdx < 0 || targetBlockIdx >= blocks.length) return;

    const movingPart =
      direction === "up"
        ? sentenceGroup.slice(0, sentenceIndex + 1)
        : sentenceGroup.slice(sentenceIndex);
    const remainingPart =
      direction === "up"
        ? sentenceGroup.slice(sentenceIndex + 1)
        : sentenceGroup.slice(0, sentenceIndex);

    const updated = [...blocks];
    updated[blockIdx] = {
      ...updated[blockIdx],
      sentences: remainingPart,
    };
    updated[targetBlockIdx] = {
      ...updated[targetBlockIdx],
      sentences:
        direction === "up"
          ? [...updated[targetBlockIdx].sentences, ...movingPart]
          : [...movingPart, ...updated[targetBlockIdx].sentences],
    };

    setBlocks(updated);
    handleMenuClose();
  };

  const startEditingChapter = (id, currentTitle) => {
    setEditingChapterId(id);
    setTempTitle(currentTitle);
  };

  const handleChapterTitleSave = (id) => {
    setBlocks((prev) =>
      prev.map((b) => (b.id === id ? { ...b, chapter_title: tempTitle } : b))
    );
    setEditingChapterId(null);
  };

  const deleteChapterBlock = (id) => {
    const block = blocks.find((b) => b.id === id);
    if (block && block.sentences.length > 0) {
      const confirmed = window.confirm("챕터 내 문장이 존재합니다. 정말 삭제하시겠습니까?\n문장이 남아있는데 삭제할 경우, 문장이 유실됩니다.");
      if (!confirmed) return;
    }
  
    setBlocks((prev) => prev.filter((b) => b.id !== id));
    setExpanded((prev) => prev.filter((x) => x !== id));
  };

  const addChapter = () => {
    if (!newTitle || !newTime) return alert("시간과 제목 입력 필요");
    const seconds = parseTime(newTime);
    const newBlock = {
      id: `block-${Date.now()}`,
      chapter_title: newTitle,
      timestamp: seconds,
      sentences: [],
    };
    setBlocks((prev) =>
      [...prev, newBlock].sort((a, b) => a.timestamp - b.timestamp)
    );
    setNewTitle("");
    setNewTime("");
  };

  const saveChanges = async () => {
    const payload = blocks.map((b) => ({
      chapter_title: b.chapter_title,
      timestamp: formatTime(b.timestamp),
      sentences: b.sentences.map((s) => ({
        text: s.text,
        timestamp: formatTime(s.timestamp),
      })),
    }));

    try {
      await axios.post(`${apiUrl}/sentences/finalize/${videoId}`, payload);
      alert("저장 완료");
      navigate(`/result/${videoId}`);
    } catch {
      alert("저장 실패");
    }
  };

  return (
    <div className={styles["page-wrapper"]}>
      <div className={styles["card"]}>
        <h2 className={styles["header-title"]}>🎬 Y-IS 편집 페이지</h2>

        <div style={{ display: "flex", gap: "32px" }}>
          <video ref={videoRef} controls className={styles["video-player"]} src={videoUrl} />
          <div className={styles["input-grid"]}>
            <h3>새 챕터 추가</h3>
            <label className={styles["input-label"]}>시간을 입력하세요 ‼️</label>
            <input
              value={newTime}
              onChange={(e) => setNewTime(e.target.value)}
              placeholder="예: 10:30"
              className={styles["input-large"]}
            />
            <label className={styles["input-label"]}>추가할 챕터 제목을 입력하세요 ‼️</label>
            <input
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="챕터 제목 입력"
              className={styles["input-large"]}
            />
            <button onClick={addChapter} className={styles["button"]}>
              ✅ 챕터 추가
            </button>
          </div>
        </div>

        <div style={{ marginTop: "32px" }}>
          {blocks.map((block) => (
            <div key={block.id} className={styles["timeline-block"]}>
              <div className={styles["timeline-header"]}>
                <div className={styles["timestamp-line"]}>
                  <span className={styles["timestamp"]}>
                    ⏱ {formatTime(block.timestamp)}
                  </span>
                  {editingChapterId === block.id ? (
                    <input
                      value={tempTitle}
                      onChange={(e) => setTempTitle(e.target.value)}
                      onBlur={() => handleChapterTitleSave(block.id)}
                      onKeyDown={(e) => e.key === "Enter" && handleChapterTitleSave(block.id)}
                      className={styles["chapter-title-input"]}
                      autoFocus
                    />
                  ) : (
                    <span
                      className={styles["chapter-title"]}
                      onClick={() => startEditingChapter(block.id, block.chapter_title)}
                      style={{ cursor: "pointer" }}
                    >
                      {block.chapter_title}
                    </span>
                  )}
                </div>
                <div style={{ display: "flex", gap: "10px" }}>
                  <button className={styles["toggle-btn"]} onClick={() => handleToggle(block.id)}>
                    {expanded.includes(block.id) ? "닫기" : "자세히 보기"}
                  </button>
                  <DeleteIcon
                    onClick={() => deleteChapterBlock(block.id)}
                    style={{ cursor: "pointer", color: "#ef4444" }}
                    titleAccess="챕터 삭제"
                  />
                </div>
              </div>

              {expanded.includes(block.id) && (
                <div className={styles["sentence-list"]}>
                  {block.sentences.map((s, i) => (
                    <div key={s.id} className={styles["sentence-row"]}>
                      <span className={styles["sentence-time"]}>
                        {formatTime(s.timestamp)}
                      </span>
                      <textarea
                        className={styles["sentence-input"]}
                        value={s.text}
                        onChange={(e) =>
                          handleSentenceChange(block.id, s.id, e.target.value)
                        }
                      />
                      <div className={styles["kebab-menu-wrapper"]}>
                        <MoreHorizIcon
                          fontSize="small"
                          style={{ cursor: "pointer" }}
                          onClick={(e) => handleMenuOpen(e, block.id, i)}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* 케밥 메뉴 */}
        <Menu
          anchorEl={anchorEl}
          open={open}
          onClose={handleMenuClose}
          anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        >
          <MenuItem onClick={() => moveSentence("up")}>위 챕터로 이동</MenuItem>
          <MenuItem onClick={() => moveSentence("down")}>아래 챕터로 이동</MenuItem>
        </Menu>

        <div className={styles["button-row"]}>
          <button onClick={() => navigate(`/result/${videoId}`)} className={`${styles["button"]} ${styles["secondary-button"]}`}>
            🔙 결과로 돌아가기
          </button>
          <button onClick={saveChanges} className={styles["button"]}>
            💾 변경 내용 저장
          </button>
        </div>
      </div>
    </div>
  );
}