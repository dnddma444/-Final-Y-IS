// ✅ ToggleHandle.js
import React from "react";
import styles from "../style/ToggleHandleStyles.module.css";

function formatTime(seconds) {
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  return hrs > 0
    ? `${hrs.toString().padStart(2, "0")}:${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
    : `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
}

export default function ToggleHandle({ blocks, onSentenceChange }) {
  const [openId, setOpenId] = React.useState(null);
  const toggle = (id) => setOpenId((prev) => (prev === id ? null : id));

  return (
    <div className={styles.timelineWrapper}>
      {blocks.map((block) => (
        <div className={styles.timelineBlock} key={block.id}>
          <div className={styles.timelineHeader}>
            <div className={styles.timestampLine}>
              <span className={styles.timestamp}>⏱ {formatTime(block.timestamp)}</span>
              <span className={styles.chapterTitle}>{block.chapter_title}</span>
              <button onClick={() => toggle(block.id)}>
                {openId === block.id ? "닫기" : "▶️ 열기"}
              </button>
            </div>
          </div>
          {openId === block.id && (
            <div className={styles.sentenceList}>
              {block.sentences.map((s, i) => (
                <textarea
                  key={i}
                  value={s}
                  onChange={(e) =>
                    onSentenceChange(block.id, i, e.target.value)
                  }
                  className={styles.sentenceInput}
                />
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}