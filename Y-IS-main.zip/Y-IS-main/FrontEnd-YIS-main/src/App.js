import "./style/ResultEditStyles.css";
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { BlocksProvider } from "./context/BlocksContext";
import { AppProvider } from "./context/AppContext";

import "./styles.css";
import "./style/HomeStyle.css";
import "./style/DownloadCompletestyle.css";

// Pages & Components
import Home from "./components/Home";
import Upload from "./components/Upload";
import Category from "./components/Category";
import ResultPage from "./components/ResultPage";
import EditPage from "./components/EditPage";
import DownloadComplete from "./components/DownloadComplete";
import ToggleHandle from "./components/ToggleHandle";
import LoadingPage from "./components/LoadingPage";

export default function App() {
  return (
    <AppProvider>
      <BlocksProvider>
        <Router>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/upload" element={<Upload />} />
            <Route path="/category" element={<Category />} />
            <Route path="/result/:videoId" element={<ResultPage />} />
            {/* ✅ videoId 파라미터 포함 */}
            <Route path="/edit/:videoId" element={<EditPage />} />
            <Route path="/complete" element={<DownloadComplete />} />
            <Route path="/toggle" element={<ToggleHandle />} />
            <Route path="/loading" element={<LoadingPage />} />
          </Routes>
        </Router>
      </BlocksProvider>
    </AppProvider>
  );
}